/*******************
	Brayden Fidler
	bfidler
	Lab 4
	Lab Section 1
	Nick Glyder
*******************/

#include <iomanip>
#include <iostream>
using namespace std;

struct point_t {
	double x;
	double y;
};

int checkPoint(point_t *p, point_t *test);

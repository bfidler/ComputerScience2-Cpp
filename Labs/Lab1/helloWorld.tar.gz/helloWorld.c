/* 
i	Brayden Fidler
	bfidler
	Lab 1
	Lab Section 1
	Name of Ta
*/

#include <stdio.h>

int main (void) {

	printf("H   H   EEEEE   L       L        OOO\n");
	printf("H   H   E       L       L       O   O\n");
	printf("HHHHH   EEEEE   L       L       O   O\n");
	printf("H   H   E       L       L       O   O\n");
	printf("H   H   EEEEE   LLLLL   LLLLL    OOO\n\n\n");
	
	printf("W     W    OOO    RRRRR   L       DDDD    !!\n");
	printf("W     W   O   O   R   R   L       D   D   !!\n");
	printf("W  W  W   O   O   RRRR    L       D   D   !!\n");
	printf(" W W W    O   O   R R     L       D   D   !!\n");
	printf("  W W      OOO    R   R   LLLLL   DDDD    oo\n");

	return 0;
}

